<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
<style type="text/css">
    
</style>
</head>  
    <body>
        <br/><br/><br/><br/>
        <center><a href='./talk_room/index.html'><font color='red' size=100px>聊天室</font></a></center>
    </body>
</html>
