<?php
	

	$DBHOST = SAE_MYSQL_HOST_M.':'.SAE_MYSQL_PORT;
	$DBUSER = SAE_MYSQL_USER;
	$DBPASSWORD = SAE_MYSQL_PASS;
	$DBNAME = SAE_MYSQL_DB;

	$conn = mysql_connect($DBHOST,$DBUSER,$DBPASSWORD) or die("连接失败".mysql_error());				//1. 获取连接
	mysql_select_db($DBNAME);																			//2. 选择数据库
	mysql_query("set names utf8");																		//3. 设置操作编码(建议有)!!!
										

?>